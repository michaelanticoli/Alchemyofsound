# Abbie / Apple Music Tailored Pitch Prototype

Files:
- `index.html` — single-page tailored pitch site
- `style.css` — styling for the prototype

Integrated links:
- Portfolio: https://strategically-yours.created.app
- LinkedIn: https://linkedin.com/in/michael-anticoli

To preview locally:
1. Open `index.html` in a browser
2. Or host the folder on Netlify / Vercel / GitHub Pages

Recommended final edits before sending:
- Add your preferred email address in the contact section
- Swap in 1-2 real examples where appropriate
- Publish and then send the outreach message from the page
